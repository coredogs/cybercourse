/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'cs', {
	title: 'Matematika v TeXu',
	button: 'Matematika',
	dialogInput: 'Zde napište TeXový kód',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'Dokumentace k TeXu',
	loading: 'Nahrává se...',
	pathName: 'Matematika'
} );
